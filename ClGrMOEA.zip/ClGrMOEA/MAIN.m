%% The Matlab implementation of ClGrMOEA written by Vikas Palakonda
clc;format compact;tic;
%-----------------------------------------------------------------------------------------
% Parameters setting
for testNo = 1 : 9

    for M = [3 5 8 10] % number of objectives
        %% Number of iterations
        if testNo == 1
            if M == 3
                Generations = 500;
            elseif M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 500;
            end
        end

        if testNo == 2
             if M == 3
                Generations = 500;
            elseif M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 500;
            end
        end

        if testNo == 3
             if M == 3
                Generations = 500;
            elseif M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 500;
            end
        end

        if testNo == 4
            if M == 3
                Generations = 500;
            elseif M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 500;
            end
        end

        if testNo == 5
             if M == 3
                Generations = 500;
            elseif M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 500;
            end
        end

        if testNo == 6
             if M == 3
                Generations = 500;
            elseif M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 500;
            end
        end

        if testNo == 7
             if M == 3
                Generations = 500;
            elseif M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 500;
            end
        end


        if testNo == 8
            if M == 3
                Generations = 500;
            elseif M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 500;
            end
        end

        if testNo == 9           
             if M == 3
                Generations = 500;
            elseif M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 500;
            end
        end

        %% -----------------------------------------------------------------------------------------
        % Algorithm parameters
        if M == 2
            N = 100;            % population size
        elseif M == 3
            N = 120;
        elseif M == 5
            N = 126;
        elseif M == 8
            N = 156;
        elseif M == 10
            N = 275;
        elseif M == 15
            N = 240;
        elseif M == 20
            N = 230;
        end

        k = M - 1;
        l = 10;

        D = l + k;

        Runs = 30;

        MinValue   = zeros(1,D);
        MaxValue   = ones(1,D);
        Boundary = [MaxValue;MinValue];
        %-----------------------------------------------------------------------------------------
        for run = 1 : Runs
            % initialize the population
            Population            = repmat(MinValue,N,1) + repmat(MaxValue - MinValue,N,1).*rand(N,D); % initial population
            FunctionValue         = F_WFG(Population,testNo,M,k);                % calculate the objective function values
            ArchiveP              = Population;
            ArchiveF              = FunctionValue;
            %-----------------------------------------------------------------------------------------
            % start iterations
            for Gene = 1 : Generations
                MatingPool                 = MatingSelection(FunctionValue);
                Offspring                  = GA(Population(MatingPool,:),{1,20,1,20},MinValue,MaxValue);
                NewFunctionValue           = F_WFG(Offspring,testNo,M,k);

                [Population,FunctionValue] = EnvironmentalSelection([Population;Offspring],[FunctionValue;NewFunctionValue],N,Gene,Generations);
                [ArchiveP,ArchiveF]        = UpdateArchive([ArchiveP;Offspring],[ArchiveF;NewFunctionValue],N);
                Gene
            end
            F_output(ArchiveP,toc,'ClGrMOEA_WFG',testNo,M,k,run);
        end
    end
    clear all;clc
end