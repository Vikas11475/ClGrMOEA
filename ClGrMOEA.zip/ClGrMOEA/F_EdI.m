function Con = F_EdI(PopObj)

[N,~]     =  size(PopObj);
Zmin      = min(PopObj,[],1);
PopObj    = PopObj - repmat(Zmin,N,1);
    
 %% Convergence indicator of each solution
 Con = sqrt(sum(PopObj.^2,2));
end