function MatingPool = MatingSelection(PopObj)
% Differental evolution with variable-wise mutation restriction

%------------------------------- Copyright --------------------------------
% Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

% This function is written by Roman Denysiuk

%% Parameter setting


[N,~]   = size(PopObj);
  

%% NewPopulation
CNum   = ceil(sqrt(N));

[IDX, ~] = kmeans(PopObj, CNum);


%% Calculate the convergence metric in each cluster
CInd = zeros(N,1);
for i = 1 : CNum
    Sg         = find(IDX == i);
    FV         = PopObj(Sg,:);
    WSR        = F_EdI(FV);
    CInd(Sg) = WSR;
end

X          = randi(CNum,N,1);

MatingPool = zeros(1,N);

for i = 1:N
    Sg = find(IDX == X(i));
    x1 = Sg(randi(size(Sg,1)));
    x2 = Sg(randi(size(Sg,1)));
    
    if CInd(x1) < CInd(x2)
        MatingPool(i) = x1;
    elseif CInd(x1) >  CInd(x2)
        MatingPool(i) = x2;
    elseif rand <= 0.5
        MatingPool(i) = x1;
    else
        MatingPool(i) = x2;
    end
end

end