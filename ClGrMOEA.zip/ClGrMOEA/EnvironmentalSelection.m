function [Population,PopObj] = EnvironmentalSelection(Population,PopObj,N,Gen,MaxGen)
% The environmental selection of GrEA

%------------------------------- Copyright --------------------------------
% Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

%% Non-dominated sorting
[FrontNo,MaxFNo] = NDSort(PopObj,N);
Next = FrontNo < MaxFNo;

%% Select the solutions in the last front
Last   = find(FrontNo==MaxFNo);
Choose = LastSelection(PopObj(Last,:),N-sum(Next),Gen,MaxGen);
Next(Last(Choose)) = true;
% Population for next generation
Population = Population(Next,:);
PopObj     = PopObj(Next,:);
end

function Choose = LastSelection(PopObj1,K,Gen,MaxGen)


%% Calculate the grid location of each solution
[NN,M] = size(PopObj1);

ratio  = Gen/MaxGen;
fac    = M - ((M-sqrt(M))* ratio);
div    = ceil((NN)^(1/fac));

fmax   = max(PopObj1,[],1);
fmin   = min(PopObj1,[],1);
lb     = fmin-(fmax-fmin)/2/div;
ub     = fmax+(fmax-fmin)/2/div;
d      = (ub-lb)/div;
lb     = repmat(lb,NN,1);
d      = repmat(d,NN,1);
GLoc   = floor((PopObj1-lb)./d);
GLoc(isnan(GLoc)) = 0;


%% Detect the grid of each solution belongs to
[~,~,XX] = unique(GLoc,'rows');
GCPD = sqrt(sum(((PopObj1-(lb+GLoc.*d))./d).^2,2));

Y = zeros(1,max(XX));
Choose = false(NN,1);
for j = 1 : max(XX)
    YY        = find(XX ==j);
    Y(j)      = length(YY);
end
[SS,order]   = sort(Y,'descend');

MV           = SS(1);
for j = 1 : MV
    for k = 1 : length(order)
        XA = length(find(Choose == 1));
        if XA < K
            gridno     = order(k);
            ff         = find(XX == gridno);
            GCPDk      = GCPD(ff);
            [~,RR]     = sort(GCPDk);

            if length(ff) >= j
                Y1         = ff(RR(j));
                Choose(Y1) = true;
            else
                Y1         = 0;
            end
        else
            return
        end
    end
    j = j + 1;
end
end